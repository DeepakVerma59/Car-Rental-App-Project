//page 1
import React  from 'react';
import {AiFillCar} from "react-icons/ai"
function Home() {

    return(
        <>
        <nav id="home-nav"><AiFillCar size={40} color='white'/></nav>
        </>
    )
}

export default Home;