// import React from 'react'
// import { Link } from 'react-router-dom'
// import "../styles/option.css"

// function Options() {
//   return <>
// <div className='header'>
//     <div className="dropdown">
//     <button type="button" className="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">
//       Car Type
//     </button>
//     <ul className="dropdown-menu">
//       <li onClick={filter}>XUV</li>
//       <li onClick={filter}>UV</li>
//       <li onClick={filter}>All</li>
//     </ul>
//   </div>

//   <div className="dropdown">
//     <button type="button" className="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">
//      Seating
//     </button>
//     <ul className="dropdown-menu">
//       <li><Link className="dropdown-item" to="#">6 seater</Link></li>
//       <li><Link className="dropdown-item" to="#">8 seater</Link></li>
//       <li><Link className="dropdown-item" to="#">All</Link></li>
//     </ul>
//   </div>

//   <div className="dropdown">
//     <button type="button" className="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">
//      Milage
//     </button>
//     <ul className="dropdown-menu">
//       <li><Link className="dropdown-item" to="#">15 KM/Hour</Link></li>
//       <li><Link className="dropdown-item" to="#">12 KM/Hour</Link></li>
//       <li><Link className="dropdown-item" to="#">All</Link></li>
//     </ul>
//   </div>
//   </div>
//   </>
// }

// export default Options
